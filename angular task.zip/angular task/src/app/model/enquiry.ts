export interface enquiry {
  id: string;
  name: string;
  email: string;
  serviceType: string;
  message: string;
}
