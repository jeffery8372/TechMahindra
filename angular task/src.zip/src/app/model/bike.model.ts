export interface Bike {
  id: number;
  name: string;
  company: string; // Added company field
  image: string;
  description: string;
  price: number;
}
